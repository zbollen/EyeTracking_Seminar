# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

#' Gaze Sample Data
#'
#' @format ## `gaze`
#' A data frame with gaze data:
#' \describe{
#'   \item{sx}{The normalized x coordinate of the 2d gaze point}
#'   \item{sy}{The normalized y coordinate of the 2d gaze point}
#'   \item{px}{The x coordinate of the 3d gaze point}
#'   \item{py}{The y coordinate of the 3d gaze point}
#'   \item{pz}{The z coordinate of the 3d gaze point}
#'   \item{ox}{The x coordinate of the 3d gaze origin}
#'   \item{oy}{The y coordinate of the 3d gaze origin}
#'   \item{oz}{The z coordinate of the 3d gaze origin}
#'   \item{timestamp}{The timestamp in milliseconds}
#'   \item{trial_id}{An arbitrary number indicating the trial ID}
#'   \item{label}{An arbitrary label}
#'   \item{svalid}{The validity flag for 2d gaze points}
#'   \item{pvalid}{The validity flag for 3d gaze points}
#'   \item{ovalid}{The validity flag for 3d gaze origins}
#' }
#' @source generated with tobii pro spart eye tracker
"gaze"
